package com.login.dao;

import com.login.domain.Authorities;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Authorities entities.
 * 
 */
public interface AuthoritiesDAO extends JpaDao {

	/**
	 * JPQL Query - findAllAuthoritiess
	 *
	 */
	public Set<Authorities> findAllAuthoritiess() throws DataAccessException;

	/**
	 * JPQL Query - findAllAuthoritiess
	 *
	 */
	public Set<Authorities> findAllAuthoritiess(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAuthoritiesByPrimaryKey
	 *
	 */
	public Authorities findAuthoritiesByPrimaryKey(Integer id) throws DataAccessException;

	/**
	 * JPQL Query - findAuthoritiesByPrimaryKey
	 *
	 */
	public Authorities findAuthoritiesByPrimaryKey(Integer id, int startResult, int maxRows) throws DataAccessException;

}