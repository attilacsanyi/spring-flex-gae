package com.login.dao;

import com.login.domain.Userinfo;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Userinfo entities.
 * 
 */
@Repository("UserinfoDAO")
@Transactional
public class UserinfoDAOImpl extends AbstractJpaDao implements UserinfoDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Userinfo.class }));

	/**
	 * EntityManager injected by Spring for persistence unit MySQL___Login
	 *
	 */
	@PersistenceContext(unitName = "MySQL___Login")
	private EntityManager entityManager;

	/**
	 * Instantiates a new UserinfoDAOImpl
	 *
	 */
	public UserinfoDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit MySQL___Login
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllUserinfos
	 *
	 */
	@Transactional
	public Set<Userinfo> findAllUserinfos() throws DataAccessException {

		return findAllUserinfos(-1, -1);
	}

	/**
	 * JPQL Query - findAllUserinfos
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Userinfo> findAllUserinfos(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllUserinfos", startResult, maxRows);
		return new LinkedHashSet<Userinfo>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserinfoByPrimaryKey
	 *
	 */
	@Transactional
	public Userinfo findUserinfoByPrimaryKey(Integer id) throws DataAccessException {

		return findUserinfoByPrimaryKey(id, -1, -1);
	}

	/**
	 * JPQL Query - findUserinfoByPrimaryKey
	 *
	 */

	@Transactional
	public Userinfo findUserinfoByPrimaryKey(Integer id, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findUserinfoByPrimaryKey", id);
		} catch (NoResultException nre) {
			return null;
		}
	}

}
