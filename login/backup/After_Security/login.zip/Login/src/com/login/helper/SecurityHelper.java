package com.login.helper;

import java.util.Map;

import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.security3.AuthenticationResultUtils;

@RemotingDestination
public class SecurityHelper {

	public Map<String, Object> getAuthentication() {
		return AuthenticationResultUtils.getAuthenticationResult();
	}

}
