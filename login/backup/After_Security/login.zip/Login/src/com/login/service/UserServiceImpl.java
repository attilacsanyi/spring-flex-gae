package com.login.service;

import com.login.dao.AuthoritiesDAO;
import com.login.dao.UserDAO;
import com.login.dao.UserinfoDAO;

import com.login.domain.Authorities;
import com.login.domain.User;
import com.login.domain.Userinfo;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.flex.remoting.RemotingDestination;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for User entities
 * 
 */

@Service("UserService")
@RemotingDestination
@Transactional
public class UserServiceImpl implements UserService, UserDetailsService {

	/**
	 * DAO injected by Spring that manages Authorities entities
	 * 
	 */
	@Autowired
	private AuthoritiesDAO authoritiesDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages Userinfo entities
	 * 
	 */
	@Autowired
	private UserinfoDAO userinfoDAO;

	/**
	 * Instantiates a new UserServiceImpl.
	 *
	 */
	public UserServiceImpl() {
	}

	/**
	 * Save an existing Userinfo entity
	 * 
	 */
	@Transactional
	public User saveUserUserinfo(Integer id, Userinfo userinfo) {
		User user = userDAO.findUserByPrimaryKey(id, -1, -1);
		Userinfo existingUserinfo = userinfoDAO.findUserinfoByPrimaryKey(userinfo.getId());

		// copy into the existing record to preserve existing relationships
		if (existingUserinfo != null) {
			existingUserinfo.setId(userinfo.getId());
			existingUserinfo.setAge(userinfo.getAge());
			existingUserinfo.setFirstname(userinfo.getFirstname());
			existingUserinfo.setLastname(userinfo.getLastname());
			userinfo = existingUserinfo;
		} else {
			userinfo = userinfoDAO.store(userinfo);
			userinfoDAO.flush();
		}

		user.setUserinfo(userinfo);
		userinfo.getUsers().add(user);
		user = userDAO.store(user);
		userDAO.flush();

		userinfo = userinfoDAO.store(userinfo);
		userinfoDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Authorities entity
	 * 
	 */
	@Transactional
	public User deleteUserAuthoritieses(Integer authorities_id, Integer user_id) {
		Authorities authorities = authoritiesDAO.findAuthoritiesByPrimaryKey(authorities_id, -1, -1);
		User user = userDAO.findUserByPrimaryKey(user_id, -1, -1);

		authorities.getUsers().remove(user);
		user.getAuthoritieses().remove(authorities);
		authorities = authoritiesDAO.store(authorities);
		authoritiesDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		authoritiesDAO.remove(authorities);
		authoritiesDAO.flush();

		return user;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public void deleteUser(User user) {
		userDAO.remove(user);
		userDAO.flush();
	}

	/**
	 * Delete an existing Userinfo entity
	 * 
	 */
	@Transactional
	public User deleteUserUserinfo(Integer user_id, Integer userinfo_id) {
		User user = userDAO.findUserByPrimaryKey(user_id, -1, -1);
		Userinfo userinfo = userinfoDAO.findUserinfoByPrimaryKey(userinfo_id, -1, -1);

		user.setUserinfo(null);
		userinfo.getUsers().remove(user);
		user = userDAO.store(user);
		userDAO.flush();

		userinfo = userinfoDAO.store(userinfo);
		userinfoDAO.flush();

		userinfoDAO.remove(userinfo);
		userinfoDAO.flush();

		return user;
	}

	/**
	 * Save an existing Authorities entity
	 * 
	 */
	@Transactional
	public User saveUserAuthoritieses(Integer id, Authorities authorities) {
		User user = userDAO.findUserByPrimaryKey(id, -1, -1);
		Authorities existingAuthorities = authoritiesDAO.findAuthoritiesByPrimaryKey(authorities.getId());

		// copy into the existing record to preserve existing relationships
		if (existingAuthorities != null) {
			existingAuthorities.setId(authorities.getId());
			existingAuthorities.setDescription(authorities.getDescription());
			existingAuthorities.setName(authorities.getName());
			authorities = existingAuthorities;
		} else {
			authorities = authoritiesDAO.store(authorities);
			authoritiesDAO.flush();
		}

		authorities.getUsers().add(user);
		user.getAuthoritieses().add(authorities);
		authorities = authoritiesDAO.store(authorities);
		authoritiesDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Load an existing User entity
	 * 
	 */
	@Transactional
	public Set<User> loadUsers() {
		return userDAO.findAllUsers();
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public void saveUser(User user) {
		User existingUser = userDAO.findUserByPrimaryKey(user.getId());

		if (existingUser != null) {
			existingUser.setId(user.getId());
			existingUser.setAccountNonExpired(user.getAccountNonExpired());
			existingUser.setAccountNonLocked(user.getAccountNonLocked());
			existingUser.setCredentialsNonExpired(user.getCredentialsNonExpired());
			existingUser.setEnabled(user.getEnabled());
			existingUser.setPassword(user.getPassword());
			existingUser.setUsername(user.getUsername());
			user = userDAO.store(existingUser);
		} else {
			user = userDAO.store(user);
		}
		userDAO.flush();
	}

	/**
	 * Called via securityHelper bean
	 * @param userName the name of the user which is authenticated or not
	 */
	@Override
	public User loadUserByUsername(String userName)
			throws UsernameNotFoundException, DataAccessException {
		User foundedUser = null;
		
		// Get all users with same name
		Set<User> users = getUsersByUsername(userName);
		
		// If users exists return the first
		if (!users.isEmpty()) {
			foundedUser = users.iterator().next();
		}
		
		return foundedUser;
	}

	@Transactional
	public Set<User> getUsersByUsername(String userName) {
		return userDAO.findUserByUsername(userName);
	}
}
