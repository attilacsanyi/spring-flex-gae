package com.login.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllUserinfos", query = "select myUserinfo from Userinfo myUserinfo"),
		@NamedQuery(name = "findUserinfoByPrimaryKey", query = "select myUserinfo from Userinfo myUserinfo where myUserinfo.id = ?1") })
@Table(catalog = "login", name = "userinfo")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "Login/com/login/domain", name = "Userinfo")
@XmlRootElement(namespace = "Login/com/login/domain")
public class Userinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer id;
	/**
	 */

	@Column(name = "age", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer age;
	/**
	 */

	@Column(name = "firstname", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstname;
	/**
	 */

	@Column(name = "lastname", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastname;

	/**
	 */
	@OneToMany(mappedBy = "userinfo", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.login.domain.User> users;

	/**
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 */
	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 */
	public Integer getAge() {
		return this.age;
	}

	/**
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 */
	public String getFirstname() {
		return this.firstname;
	}

	/**
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 */
	public String getLastname() {
		return this.lastname;
	}

	/**
	 */
	public void setUsers(Set<User> users) {
		this.users = users;
	}

	/**
	 */
	public Set<User> getUsers() {
		if (users == null) {
			users = new java.util.LinkedHashSet<com.login.domain.User>();
		}
		return users;
	}

	/**
	 */
	public Userinfo() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Userinfo that) {
		setId(that.getId());
		setAge(that.getAge());
		setFirstname(that.getFirstname());
		setLastname(that.getLastname());
		setUsers(new java.util.LinkedHashSet<com.login.domain.User>(that.getUsers()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("id=[").append(id).append("] ");
		buffer.append("age=[").append(age).append("] ");
		buffer.append("firstname=[").append(firstname).append("] ");
		buffer.append("lastname=[").append(lastname).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Userinfo))
			return false;
		Userinfo equalCheck = (Userinfo) obj;
		if ((id == null && equalCheck.id != null) || (id != null && equalCheck.id == null))
			return false;
		if (id != null && !id.equals(equalCheck.id))
			return false;
		return true;
	}
}
