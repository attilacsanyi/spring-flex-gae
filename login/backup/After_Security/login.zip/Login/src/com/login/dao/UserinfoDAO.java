package com.login.dao;

import com.login.domain.Userinfo;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Userinfo entities.
 * 
 */
public interface UserinfoDAO extends JpaDao {

	/**
	 * JPQL Query - findAllUserinfos
	 *
	 */
	public Set<Userinfo> findAllUserinfos() throws DataAccessException;

	/**
	 * JPQL Query - findAllUserinfos
	 *
	 */
	public Set<Userinfo> findAllUserinfos(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserinfoByPrimaryKey
	 *
	 */
	public Userinfo findUserinfoByPrimaryKey(Integer id) throws DataAccessException;

	/**
	 * JPQL Query - findUserinfoByPrimaryKey
	 *
	 */
	public Userinfo findUserinfoByPrimaryKey(Integer id, int startResult, int maxRows) throws DataAccessException;

}