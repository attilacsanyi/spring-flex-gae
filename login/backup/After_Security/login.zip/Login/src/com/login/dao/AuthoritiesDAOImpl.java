package com.login.dao;

import com.login.domain.Authorities;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Authorities entities.
 * 
 */
@Repository("AuthoritiesDAO")
@Transactional
public class AuthoritiesDAOImpl extends AbstractJpaDao implements
		AuthoritiesDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Authorities.class }));

	/**
	 * EntityManager injected by Spring for persistence unit MySQL___Login
	 *
	 */
	@PersistenceContext(unitName = "MySQL___Login")
	private EntityManager entityManager;

	/**
	 * Instantiates a new AuthoritiesDAOImpl
	 *
	 */
	public AuthoritiesDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit MySQL___Login
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAllAuthoritiess
	 *
	 */
	@Transactional
	public Set<Authorities> findAllAuthoritiess() throws DataAccessException {

		return findAllAuthoritiess(-1, -1);
	}

	/**
	 * JPQL Query - findAllAuthoritiess
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Authorities> findAllAuthoritiess(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllAuthoritiess", startResult, maxRows);
		return new LinkedHashSet<Authorities>(query.getResultList());
	}

	/**
	 * JPQL Query - findAuthoritiesByPrimaryKey
	 *
	 */
	@Transactional
	public Authorities findAuthoritiesByPrimaryKey(Integer id) throws DataAccessException {

		return findAuthoritiesByPrimaryKey(id, -1, -1);
	}

	/**
	 * JPQL Query - findAuthoritiesByPrimaryKey
	 *
	 */

	@Transactional
	public Authorities findAuthoritiesByPrimaryKey(Integer id, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findAuthoritiesByPrimaryKey", id);
		} catch (NoResultException nre) {
			return null;
		}
	}

}
