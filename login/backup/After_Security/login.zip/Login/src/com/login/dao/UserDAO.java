package com.login.dao;

import com.login.domain.User;

import java.util.Set;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage User entities.
 * 
 */
public interface UserDAO extends JpaDao {

	/**
	 * JPQL Query - findUserByAccountNonExpired
	 *
	 */
	public Set<User> findUserByAccountNonExpired(Boolean accountNonExpired) throws DataAccessException;

	/**
	 * JPQL Query - findUserByAccountNonExpired
	 *
	 */
	public Set<User> findUserByAccountNonExpired(Boolean accountNonExpired, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUsernameContaining
	 *
	 */
	public Set<User> findUserByUsernameContaining(String username) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUsernameContaining
	 *
	 */
	public Set<User> findUserByUsernameContaining(String username, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPassword
	 *
	 */
	public Set<User> findUserByPassword(String password) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPassword
	 *
	 */
	public Set<User> findUserByPassword(String password, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPasswordContaining
	 *
	 */
	public Set<User> findUserByPasswordContaining(String password_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPasswordContaining
	 *
	 */
	public Set<User> findUserByPasswordContaining(String password_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByAccountNonLocked
	 *
	 */
	public Set<User> findUserByAccountNonLocked(Boolean accountNonLocked) throws DataAccessException;

	/**
	 * JPQL Query - findUserByAccountNonLocked
	 *
	 */
	public Set<User> findUserByAccountNonLocked(Boolean accountNonLocked, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPrimaryKey
	 *
	 */
	public User findUserByPrimaryKey(Integer id) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPrimaryKey
	 *
	 */
	public User findUserByPrimaryKey(Integer id, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUsername
	 *
	 */
	public Set<User> findUserByUsername(String username_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUsername
	 *
	 */
	public Set<User> findUserByUsername(String username_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllUsers
	 *
	 */
	public Set<User> findAllUsers() throws DataAccessException;

	/**
	 * JPQL Query - findAllUsers
	 *
	 */
	public Set<User> findAllUsers(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByEnabled
	 *
	 */
	public Set<User> findUserByEnabled(Boolean enabled) throws DataAccessException;

	/**
	 * JPQL Query - findUserByEnabled
	 *
	 */
	public Set<User> findUserByEnabled(Boolean enabled, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByCredentialsNonExpired
	 *
	 */
	public Set<User> findUserByCredentialsNonExpired(Boolean credentialsNonExpired) throws DataAccessException;

	/**
	 * JPQL Query - findUserByCredentialsNonExpired
	 *
	 */
	public Set<User> findUserByCredentialsNonExpired(Boolean credentialsNonExpired, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserById
	 *
	 */
	public User findUserById(Integer id_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserById
	 *
	 */
	public User findUserById(Integer id_1, int startResult, int maxRows) throws DataAccessException;

}