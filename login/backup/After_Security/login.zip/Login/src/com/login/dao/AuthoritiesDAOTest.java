package com.login.dao;

import com.login.domain.Authorities;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.test.annotation.Rollback;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;

import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import org.springframework.transaction.annotation.Transactional;

/**
 * Class used to test the basic Data Store Functionality
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@Transactional
@ContextConfiguration(locations = {
		"file:./resources/Login-generated-security-context.xml",
		"file:./resources/Login-security-context.xml",
		"file:./resources/Login-generated-service-context.xml",
		"file:./resources/Login-service-context.xml",
		"file:./resources/Login-generated-dao-context.xml",
		"file:./resources/Login-dao-context.xml",
		"file:./resources/Login-generated-web-context.xml",
		"file:./resources/Login-web-context.xml" })
public class AuthoritiesDAOTest {
	/**
	 * The DAO being tested, injected by Spring
	 *
	 */
	private AuthoritiesDAO dataStore;

	/**
	 * Instantiates a new AuthoritiesDAOTest.
	 *
	 */
	public AuthoritiesDAOTest() {
	}

	/**
	 * Method to test Authorities domain object.
	 *
	 */
	@Rollback(false)
	@Test
	public void Authorities() {
		Authorities instance = new Authorities();

		// Test create				
		// TODO: Populate instance for create.  The store will fail if the primary key fields are blank.				

		// store the object
		dataStore.store(instance);

		// Test update
		// TODO: Modify non-key domain object values for update

		// update the object
		dataStore.store(instance);

		// Test delete
		dataStore.remove(instance);

	}

	/**
	 * Method to allow Spring to inject the DAO that will be tested
	 *
	 */
	@Autowired
	public void setDataStore(AuthoritiesDAO dataStore) {
		this.dataStore = dataStore;
	}
}
