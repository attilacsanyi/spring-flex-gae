package com.login.service;

import com.login.domain.Authorities;
import com.login.domain.User;
import com.login.domain.Userinfo;

import java.util.Set;

/**
 * Spring service that handles CRUD requests for User entities
 * 
 */
public interface UserService {

	/**
	 * Save an existing Userinfo entity
	 * 
	 */
	public User saveUserUserinfo(Integer id, Userinfo userinfo);

	/**
	 * Delete an existing Authorities entity
	 * 
	 */
	public User deleteUserAuthoritieses(Integer authorities_id, Integer user_id);

	/**
	 * Delete an existing User entity
	 * 
	 */
	public void deleteUser(User user);

	/**
	 * Delete an existing Userinfo entity
	 * 
	 */
	public User deleteUserUserinfo(Integer user_id_1, Integer userinfo_id);

	/**
	 * Save an existing Authorities entity
	 * 
	 */
	public User saveUserAuthoritieses(Integer id_1, Authorities authorities);

	/**
	 * Load an existing User entity
	 * 
	 */
	public Set<User> loadUsers();

	/**
	 * Save an existing User entity
	 * 
	 */
	public void saveUser(User user_1);
}