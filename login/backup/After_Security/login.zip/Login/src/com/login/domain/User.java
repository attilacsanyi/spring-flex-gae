package com.login.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.userdetails.UserDetails;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllUsers", query = "select myUser from User myUser"),
		@NamedQuery(name = "findUserByAccountNonExpired", query = "select myUser from User myUser where myUser.accountNonExpired = ?1"),
		@NamedQuery(name = "findUserByAccountNonLocked", query = "select myUser from User myUser where myUser.accountNonLocked = ?1"),
		@NamedQuery(name = "findUserByCredentialsNonExpired", query = "select myUser from User myUser where myUser.credentialsNonExpired = ?1"),
		@NamedQuery(name = "findUserByEnabled", query = "select myUser from User myUser where myUser.enabled = ?1"),
		@NamedQuery(name = "findUserById", query = "select myUser from User myUser where myUser.id = ?1"),
		@NamedQuery(name = "findUserByPassword", query = "select myUser from User myUser where myUser.password = ?1"),
		@NamedQuery(name = "findUserByPasswordContaining", query = "select myUser from User myUser where myUser.password like ?1"),
		@NamedQuery(name = "findUserByPrimaryKey", query = "select myUser from User myUser where myUser.id = ?1"),
		@NamedQuery(name = "findUserByUsername", query = "select myUser from User myUser where myUser.username = ?1"),
		@NamedQuery(name = "findUserByUsernameContaining", query = "select myUser from User myUser where myUser.username like ?1") })
@Table(catalog = "login", name = "user")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "Login/com/login/domain", name = "User")
public class User implements Serializable, UserDetails {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer id;
	/**
	 */

	@Column(name = "account_non_expired", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean accountNonExpired;
	/**
	 */

	@Column(name = "account_non_locked", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean accountNonLocked;
	/**
	 */

	@Column(name = "credentials_non_expired", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean credentialsNonExpired;
	/**
	 */

	@Column(name = "enabled", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean enabled;
	/**
	 */

	@Column(name = "password", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String password;
	/**
	 */

	@Column(name = "username", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String username;

	/**
	 */
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumns({ @JoinColumn(name = "userinfo_id", referencedColumnName = "id", unique = true) })
	@XmlTransient
	Userinfo userinfo;
	/**
	 */
	@ManyToMany(mappedBy = "users", fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<com.login.domain.Authorities> authoritieses;

	/**
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 */
	public void setAccountNonExpired(Boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	/**
	 */
	public Boolean getAccountNonExpired() {
		return this.accountNonExpired;
	}

	/**
	 */
	public void setAccountNonLocked(Boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	/**
	 */
	public Boolean getAccountNonLocked() {
		return this.accountNonLocked;
	}

	/**
	 */
	public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	/**
	 */
	public Boolean getCredentialsNonExpired() {
		return this.credentialsNonExpired;
	}

	/**
	 */
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 */
	public Boolean getEnabled() {
		return this.enabled;
	}

	/**
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 */
	public String getUsername() {
		return this.username;
	}

	/**
	 */
	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

	/**
	 */
	public Userinfo getUserinfo() {
		return userinfo;
	}

	/**
	 */
	public void setAuthoritieses(Set<Authorities> authoritieses) {
		this.authoritieses = authoritieses;
	}

	/**
	 */
	public Set<Authorities> getAuthoritieses() {
		if (authoritieses == null) {
			authoritieses = new java.util.LinkedHashSet<com.login.domain.Authorities>();
		}
		return authoritieses;
	}

	/**
	 */
	public User() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(User that) {
		setId(that.getId());
		setAccountNonExpired(that.getAccountNonExpired());
		setAccountNonLocked(that.getAccountNonLocked());
		setCredentialsNonExpired(that.getCredentialsNonExpired());
		setEnabled(that.getEnabled());
		setPassword(that.getPassword());
		setUsername(that.getUsername());
		setUserinfo(that.getUserinfo());
		setAuthoritieses(new java.util.LinkedHashSet<com.login.domain.Authorities>(that.getAuthoritieses()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("id=[").append(id).append("] ");
		buffer.append("accountNonExpired=[").append(accountNonExpired).append("] ");
		buffer.append("accountNonLocked=[").append(accountNonLocked).append("] ");
		buffer.append("credentialsNonExpired=[").append(credentialsNonExpired).append("] ");
		buffer.append("enabled=[").append(enabled).append("] ");
		buffer.append("password=[").append(password).append("] ");
		buffer.append("username=[").append(username).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof User))
			return false;
		User equalCheck = (User) obj;
		if ((id == null && equalCheck.id != null) || (id != null && equalCheck.id == null))
			return false;
		if (id != null && !id.equals(equalCheck.id))
			return false;
		return true;
	}

	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		
		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		
		for(Authorities authority : authoritieses) {
			authorities.add(new GrantedAuthorityImpl(authority.getName()));
		}
		
		return authorities;
	}

	@Override
	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}
}
